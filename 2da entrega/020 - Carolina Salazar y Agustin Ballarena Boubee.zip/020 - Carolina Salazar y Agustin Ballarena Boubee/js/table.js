"use strict";

//-----------------------EventListeners----------------------------

document.addEventListener("DOMContentLoaded", preLoad);
document.querySelector("#btn-add1").addEventListener("click", add1);
document.querySelector("#btn-add3").addEventListener("click", add3);
document.querySelector("#btn-delete").addEventListener("click", reset);

let table = [
    {
        excursion: "Visita al Vaticano",
        name: "Roger",
        age: 25,
        time: 15,
        language: "Español",
    },
    {
        excursion: "Coliseo, Foro y Palatino",
        name: "Rafa",
        age: 16,
        time: 12,
        language: "Italiano",
    },
    {
        excursion: "Excursión a las Catacumbas",
        name: "Novak",
        age: 11,
        time: 14,
        language: "Inglés",
    },
    {
        excursion: "Tour Gastronómico",
        name: "Andy",
        age: 52,
        time: 11,
        language: "Italiano",
    },
    {
        excursion: "Tour Nocturno",
        name: "Dominic",
        age: 30,
        time: 21,
        language: "Español",
    }
]

//-------------------------PRECARGA----------------------------

function preLoad() {
    displayTable();
}

//------------------------MOSTRAR TABLA------------------------

function displayTable() {
    let tableExcursions = document.querySelector("#table");
    tableExcursions.innerHTML = '';
    for (let i = 0; i < table.length; i++) {
        if (table[i].age <= 12) {
            tableExcursions.innerHTML +=
                `<tr>
                    <td class="highlighted">${table[i].excursion}</td>
                    <td class="highlighted">${table[i].name}</td>
                    <td class="highlighted">${table[i].age}</td>
                    <td class="highlighted">${table[i].time}</td>
                    <td class="highlighted">${table[i].language}</td>
                </tr>`;
        }
        else {
            tableExcursions.innerHTML +=
                `<tr>
                    <td>${table[i].excursion}</td>
                    <td>${table[i].name}</td>
                    <td>${table[i].age}</td>
                    <td>${table[i].time}</td>
                    <td>${table[i].language}</td>
                </tr>`;
        }
    }
}

//----------------------AGREGAR UN REGISTRO--------------------

function add1() {
    let excursion = document.querySelector("#input-excursion").value;
    let name = document.querySelector("#input-name").value;
    let age = document.querySelector("#input-age").value;
    let time = document.querySelector("#input-time").value;
    let language = document.querySelector("#input-language").value;

    let newRecord = {
        excursion: excursion,
        name: name,
        age: parseInt(age),
        time: parseInt(time),
        language: language,
    }

    table.push(newRecord);
    document.querySelector("form").reset();
    displayTable();
}

//-------------------AGREGAR TRES REGISTROS--------------

function add3() {

    let firstRecord = {
        excursion: "Tour de las leyendas",
        name: "Serena",
        age: 29,
        time: 8,
        language: "Italiano",
    }

    table.push(firstRecord);

    let secondRecord = {
        excursion: "Crucero por el Río Tiber",
        name: "Maria",
        age: 34,
        time: 13,
        language: "Inglés",
    }

    table.push(secondRecord);

    let thirdRecord = {
        excursion: "Tour por las Iglesias Barrocas",
        name: "Simona",
        age: 8,
        time: 12,
        language: "Español",
    }

    table.push(thirdRecord);

    document.querySelector("form").reset();
    displayTable();
}

//-------------------BORRAR REGISTROS--------------------

function reset() {
    table = [];
    displayTable();
}
